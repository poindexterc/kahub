<?php
require_once 'AppCode/access.class.php';
$user = new flexibleAccess();
require_once 'AppCode/MasterPageScript.php'; 
require_once 'AppCode/ApplicationSettings.php';
require_once 'AppCode/HelpingDBMethods.php';
require_once 'AppCode/HelpingMethods.php';
require_once 'AppCode/SideBarScript.php';

$rootURL = Settings::GetRootURL();
$LiteralHeadScript = MasterPage::GetHeadScript();
$LiteralHeader = MasterPage::GetHeader();
$LiteralSideBar = "";
$LiteralFooter = MasterPage::GetFooter();
$LiteralContent = "";
$LiteralCategoryName ="SOPIDER";
$LiteralSocialMediaLinks = "";//HelpingMethods::GetSocialMediaLinks();
//$LiteralTimeSpanLinks = HelpingMethods::GetTimeSpanLinks();
//$LiteralChannelLinks = HelpingMethods::GetChannelLinks();
$pageTitle = "SOPIDER | Social Spider";
HomePage::Page_Load();
	echo <<<Content
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang='en'>	
	<head>		
		<title>{$pageTitle}</title>
{$LiteralHeadScript}		
	</head>
	<body>
{$LiteralHeader}

        <div class="main-wrap">
            <div id="main" class="page wrapper">
                 <div id="contents">
                    <a href="http://feeds.feedburner.com/sopider" class="sprites btn-subscribe">Subscribe</a>
			<p class="tabs wrapper">
			</p>                 
                    <div class="sprites bg-contents-top"></div>
                    <div class="bg-contents-mid">						
						<div class = "clear"></div>
                        {$LiteralContent}                        
                     </div>
                     <div class="sprites bg-contents-bot"></div>
                 </div><!--content ends here -->
                 <div id="sidebar">
{$LiteralSideBar}
		 </div>
		 <div class="cl"></div>
            </div><!-- main ends here -->
        </div><!-- main-wrap ends here -->
        
{$LiteralFooter}
        </body>
</html>	
Content;

class HomePage
{
	public function Page_Load()
	{
		$DBConnection = Settings::ConnectDB(); 		
		if($DBConnection)
		{
			$db_selected = mysql_select_db(Settings::GetDatabaseName(), $DBConnection) or die(mysql_error());
			if($db_selected)
			{
				//HomePage::SetContent();
				HomePage::SetSideBar();
				//$GLOBALS['LiteralContent'] = '<a href = "morestories(1, 1, 1, 100)">hello</a>';
			}
			mysql_close($DBConnection);
		}
		
	}
	
	function SetContent()
	{		
		$resultsPerPage = 10;
		$offSet = 0;
		$totalResults = 0;
		
		//$RegionRequested = RequestQueries::GetRegion();
		
		$CategoryID = 0;
		$RegionID = 0;
		if(isset($RegionRequested))
		{
			$RegionID = HelpingDBMethods::GetRegionID(strtolower($RegionRequested));			
		}		

		$CategoryID = RequestQueries::GetCategory();
               	$TimeSpan = HelpingMethods::TranslateTimeSpan(RequestQueries::GetTimeSpan());	
		$type = RequestQueries::GetType();
		$socialmediatype = RequestQueries::GetSocialMediaType();
        $ChannelID = RequestQueries::GetChannel();  

                $GLOBALS['pageTitle'] = HomePage::GetIndexPageTitle($CategoryID, RequestQueries::GetTimeSpan(), $type);

		$Query = HelpingMethods::PrepareQuery($ChannelID, $RegionID, $CategoryID, $offSet, $resultsPerPage, $TimeSpan, $socialmediatype, $type);		
		HomePage::SetResultList($Query, $ChannelID, $RegionID, $CategoryID, $offSet, RequestQueries::GetTimeSpan(), $resultsPerPage, $socialmediatype, $type);		

	}

    public function GetIndexPageTitle($CategoryID, $TimeSpan, $PopularityType)
        {
            $PopularityTypeString = "Popular";
            if($PopularityType != 'popular')
            {
                $PopularityTypeString = "Trending";
            }
            
            $TimeSpanString = "";
            if($TimeSpan == '24h')
            {
                $TimeSpanString = " In Last 24 Hours";
            }
            else if($TimeSpan == 'lastweek')
            {
                $TimeSpanString = " In Last Week";
            }

            $CategoryName = " ";
            switch($CategoryID)
            {
                case 1:
                    $CategoryName = " World ";
                    break;

                case 2:
                    $CategoryName = " Business ";
                    break;

                case 3:
                    $CategoryName = " Entertainment ";
                    break;

                case 4:
                    $CategoryName = " Sports ";
                    break;

                case 5:
                    $CategoryName = " Technology ";
                    break;

                case 6:
                    $CategoryName = " Science ";
                    break;

                case 7:
                    $CategoryName = " Offbeat ";
                    break;
            }
            
            $Result = $PopularityTypeString.$CategoryName." News From Around The World".$TimeSpanString." | SOPIDER";
            return $Result;
        }

	public function SetResultList($Query, $channelid, $regionid, $categoryid, $offset, $timespan, $resultsperpage, $socialmediatype, $type)
	{
		$result = "";
		$totalResults = 1000;
		
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		if($row != false)
		{
			$result .= '<div id = "recent-posts"><ul class="recent-posts">';
                        	
			while($row != false)
			{
				$result .= HelpingMethods::SetStoryRowContent($row, true);
				$row = mysql_fetch_array($QueryResult);					
			}
                        $result .= '</ul></div>';
			
			if($totalResults > ($offset + $resultsperpage))
			{
                            //$result .= '<div style = "padding-top:20px;"><a id = "more-content" class = "more round" href = "javascript:morestories(' . $region . ', ' . $category . ', \'' . $_POST['timespan'] . '\', ' . ($offset + $resultsperpage) . ', ' . $totalResults . ', ' . $socialmediatype . ', \'' . $type . '\')">more</a></div>';
                             $result .= '<p class="sprites blue-box" id = "more-content"><a href = "javascript:morestories(' . $channelid . ', ' . $regionid . ', ' . $categoryid . ', \'' . $timespan . '\', ' . ($offset + $resultsperpage) . ', ' . $totalResults . ', ' . $socialmediatype . ', \'' . $type . '\');" class="sprites arrow-down">More</a></p>';
			}
			
		}
		else
		{
                        $result .= '<p class="sprites blue-box" id = "more-content">No more results were found!</p>';
		}
		$GLOBALS['LiteralContent'] = $result;
		//$GLOBALS['LiteralContent'] = $Query;
	}
	
	function SetSideBar()
	{
		$GLOBALS['LiteralSideBar'] = '<h2 class="sprites section-header">Browse Topics</h2>
									 <div class="bg-sidebar-mid">
										 ' . 
										 //SideBar::GetBrowseLinks() . 
										 '
									 </div>
									 <div class="sprites bg-sidebar-bot"></div>									 
									 
									 <h2 class="sprites section-header">Top in '. HelpingMethods::GetCurrentCategoryName().' </h2>
									 <div class="bg-sidebar-mid">
										 ' . 
										 //SideBar::GetTopTen() . 
										 '
									 </div>
									 <div class="sprites bg-sidebar-bot"></div>
									 
									 <!--<div class="sprites section-header"></div>
										<div class="bg-sidebar-mid">
											<iframe src="http://www.facebook.com/plugins/likebox.php?id=128208967224245&amp;width=211&amp;connections=9&amp;stream=false&amp;header=true&amp;height=287" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:211px; height:287px;" allowTransparency="true"></iframe>
										</div>
									 <div class="sprites bg-sidebar-bot"></div>-->
									 
									 
									 ';
	}
}
?>