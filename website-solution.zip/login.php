<?php
require_once 'AppCode/access.class.php';
$user = new flexibleAccess();
require_once 'AppCode/MasterPageScript.php';

$LiteralMessage = "Please Enter Your User Name And Password To Login.";
$LiteralContent = "";
Login::Page_Load();

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';
echo '<html xmlns="http://www.w3.org/1999/xhtml">';
echo '	<head>';
echo '		<title>e-ListMania: Home � Login</title>';
echo "		<link id ='ss_category' href='" . $GLOBALS['rootURL'] . "style/not-found.css' rel='stylesheet' type='text/css' media='all' />
			<link href='" . $GLOBALS['rootURL'] . "style/FAQStyleSheet.css' rel='stylesheet' type='text/css' />";
echo		MasterPage::GetHeadScript();
echo '	</head>';
echo '	<body>';

//echo		MasterPage::GetHeader();
echo '		<div class="mainDiv">';	
echo '	        <!-- Content Page Code Starts -->';
				//Home Page Content Area Starts
echo			$LiteralContent;
				//Home Page Content Area Ends				    
echo '	        <!-- Content Page Code Ends --> ';
echo '	        <div class="clear" ></div>';
echo '	    </div>';
//echo		MasterPage::GetFooter();
echo '	</body>';
echo '</html>';

class Login
{
	function Page_Load()
	{
		$DBConnection = Settings::ConnectDB(); 		
		if($DBConnection)
		{
			$db_selected = mysql_select_db($GLOBALS['databaseName'], $DBConnection) or die(mysql_error());
			if($db_selected)
			{
				if (isset($_POST['btnLogin'])) 
				{
					$isSuccessfull = false;
					$un = $_POST['un'];
					$password = $_POST['p'];
					$remember = false;
					if(isset($_POST['remember']))
					{
						$remember = true;
					}
					if($un == "")
					{
						$GLOBALS['LiteralMessage'] = "<div class = 'errorBox' style ='width:80%;'><div class='loading-image'>User Name Required</div></div>";
						Login::SetPageContents($un);
					}
					elseif($password == "")
					{
						$GLOBALS['LiteralMessage'] = "<div class = 'errorBox' style ='width:80%;'><div class='loading-image'>Password Required</div></div>";
						Login::SetPageContents($un);
					}
					else
					{
						$user = new flexibleAccess();
						$response = $user->login($un,$password,$remember);
						if($response == true)
						{							
							//$returnURL = RequestQueries::GetReturnURL();
							$returnURL = '/admin/';
							if(preg_match('/login.php/', $returnURL) || $returnURL == '')
							{
								$returnURL = '/admin/';
							}
							header('Location: ' . $returnURL);
							Login::SetPageContents($un);		
						}
						else
						{
							$GLOBALS['LiteralMessage'] = "<div class = 'errorBox' style ='width:80%;'><div class='loading-image'>Invalid User Name or Password</div></div>";
							Login::SetPageContents($un);
						}
					}
				}				
				else
				{
					Login::SetPageContents("", "");
				}				
			}
			mysql_close($DBConnection);
		}
	}
	
	function SetPageContents($un)
	{
		
		$GLOBALS['LiteralContent'] = <<<NotFound_Page
		<div class="big-box">
			<div class="error_title">Login</div>
			<div class="error_bg">{$GLOBALS['LiteralMessage']}
				 <form method = "post">
					<table>
						<tr>
							<td>
								User Name
							</td>
							<td>
								<input name = "un" type = "text" value = "{$un}" style = "width:200px;"/>
							</td>
						</tr>
						<tr>
							<td>
								Password
							</td>
							<td>
								<input name = "p" type = "password" style = "width:200px;"/>
							</td>
						</tr>
						<tr>
							<td>
								Remember me? 
							</td>
							<td>
								<input type="checkbox" name="remember" value="1" />
								<span style = "float:right;">
									<input name = "btnLogin" type = "submit" value = "Login" class = "btn"/>
								</span>
							</td>							
						</tr>
					</table>
				 </form>
			</div>
		</div>
		<div class="clear"></div>

NotFound_Page;
	}
}
?>