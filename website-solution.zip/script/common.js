var defaultText = "Enter your text here";
function WaterMark(txt, evt, textName)
{
	defaultText = textName;
	if(txt.value.length == 0 && evt.type == "blur")
	{
		txt.style.color = "gray";
		txt.value = defaultText;
	}
	if(txt.value == defaultText && evt.type == "focus")
	{
		txt.style.color = "black";
		txt.value="";
	}
}

function swapdisplay(currentCaller)
{
    if(currentCaller == "heading-pop")
    {
        if($j("#heading-pop").hasClass('expandable'))
        {
            $j("#heading-pop").removeClass('expandable').addClass('collapseable');
        }
        else
        {
            $j("#heading-pop").removeClass('collapseable').addClass('expandable');
        }
        $j("#popular-links").toggle("slow");
        $j("#perspective-links").hide("slow");
        $j("#region-links").hide("slow");
    }
    else if(currentCaller == "heading-per")
    {
        if($j("#heading-per").hasClass('expandable'))
        {
            $j("#heading-per").removeClass('expandable').addClass('collapseable');
        }
        else
        {
            $j("#heading-per").removeClass('collapseable').addClass('expandable');
        }
        $j("#popular-links").hide("slow");
        $j("#perspective-links").toggle("slow");
        $j("#region-links").hide("slow");
    }
    else if(currentCaller == "heading-region")
    {
        if($j("#heading-region").hasClass('expandable'))
        {
            $j("#heading-region").removeClass('expandable').addClass('collapseable');
        }
        else
        {
            $j("#heading-region").removeClass('collapseable').addClass('expandable');
        }
        $j("#popular-links").hide("slow");
        $j("#perspective-links").hide("slow");
        $j("#region-links").toggle("slow");
    }
    
}

function countCharacters(id,max_chars,myelement)  
{  
	counter = document.getElementById(id);  
	field = document.getElementById(myelement).value;  
	field_length = field.length;  
	if (field_length <= max_chars)  
	{     
		// Here we Calculate remaining characters     
		remaining_characters = max_chars-field_length;   
		// Now Update the counter on the page  
		counter.innerHTML = remaining_characters;  
	}  
 }
