<?php
require_once 'ApplicationSettings.php';
require_once 'HelpingMethods.php';
class MemberDBMethods
{	
	function isUserNameAvailable($username)
	{
		$result = false;
		$Query = "SELECT MemberID FROM tbl_member WHERE mUserName = '$username'";	
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		if($row!=false)
		{
			$result = false;
		}
		else
		{
			$result = true;
		}
		return $result;
	}
	
	function isEmailAvailable($email)
	{
		$result = false;
		$Query = "SELECT MemberID FROM tbl_member WHERE mEmail = '$email'";	
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		if($row!=false)
		{
			$result = false;
		}
		else
		{
			$result = true;
		}
		return $result;
	}
	
	function AddMember($un, $email, $p)
	{
		$DateTime = gmdate("Y-m-d H-i-s");//date('Y-m-d H-i-s')
		$Query = "INSERT INTO tbl_member (mFirst_Name, mEmail, mUserName, mPassword) 
				VALUES ('" . $un . "', '" . $email . "', '" . $un . "', '" . $p . "')";
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		return mysql_insert_id();
	}
	
	function GetUserName($memberID)
	{
		$result = "";
		$Query = "SELECT mFirst_Name, mLast_Name FROM tbl_member WHERE MemberID = '$memberID'";	
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		if($row!=false)
		{
			$result = $row['mFirst_Name'] . " " . $row['mLast_Name'];
		}
		else
		{
			$result = "";
		}
		return $result;
	}
	
	function GetUserEmail($memberID)
	{
		$result = "";
		$Query = "SELECT mEmail FROM tbl_member WHERE MemberID = '$memberID'";	
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		if($row!=false)
		{
			$result = $row['mEmail'];
		}
		else
		{
			$result = "";
		}
		return $result;
	}
	
	function GetMemberIDByUserName($un)
	{
		$result = 0;
		$Query = "SELECT MemberID FROM tbl_member WHERE mUserName = '$un'";	
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		if($row!=false)
		{
			$result = $row['MemberID'];
		}
		return $result;
	}
	
	function GetUserPassword($userID)
	{
		$result = "";
		$Query = "SELECT mPassword FROM tbl_member WHERE MemberID = '$userID'";	
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		if($row!=false)
		{
			$result = $row['mPassword'];
		}
		return $result;
	}
	
	function UpdateMemberImage($userID, $ImageID)
	{
		$Query = "UPDATE tbl_member	SET ImageID = $ImageID	WHERE MemberID=$userID";
		$QueryResult =  mysql_query($Query)or die(mysql_error());
	}
}

?>