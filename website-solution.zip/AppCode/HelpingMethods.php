<?php
require_once 'ApplicationSettings.php';
require_once 'RequestQuery.php';
require_once 'HelpingDBMethods.php';
require_once 'CommentsMethods.php';
class HelpingMethods
{	
	function TranslateTimeSpan($TimeSpan)
	{
		$result = "recent";
		if($TimeSpan == "recent")
		{
			$result = "recent";
		}
		elseif($TimeSpan == "24h")
		{
			$result = "1 Day";
		}
		elseif($TimeSpan == "lastweek")
		{
			$result = "7 Day";
		}			
		
		
		return $result;
	}
	
	function GetDomain($url)
	{
		$url = parse_url($url);		
		return str_replace("www.","", $url['host']);		
	}
	
	function GetLongDateTime($stringdatetime)
	{
		$result = "";
		date_default_timezone_set('UTC');
		$datetime = strtotime($stringdatetime);
		$currenttime = mktime();
		$diff = $currenttime - $datetime;

		if($diff < 60)
		{
			if($diff == 1)
				$result = $diff ." second ago";
			else
				$result = $diff ." seconds ago";
		}
		elseif($diff < (60 * 60))
		{
			$diff = floor($diff / 60);
			if($diff == 1)
				$result = $diff ." minute ago";
			else
				$result = $diff ." minutes ago";
		}
		elseif($diff < (60 * 60 * 24))
		{
			$minutes = $diff % (60 * 60);
			$minutes = floor($minutes / 60);
			$minutestext = "";
			
			if($minutes > 0)
			{
				if($minutes == 1)
					$minutestext = " ".$minutes." minute";
				else
					$minutestext = " ".$minutes ." minutes";
			}

			$diff = floor($diff / (60 * 60));
			if($diff == 1)
				$result = $diff ." hour".$minutestext." ago";
			else
				$result = $diff ." hours".$minutestext." ago";
		}
		elseif($diff < (60 * 60 * 24 * 7))
		{
			$hours = $diff % (60 * 60 * 24);
			$hours = floor($hours / (60 * 60));
			$hourstext = "";
			
			if($hours > 0)
			{
				if($hours == 1)
					$hourstext = " ".$hours ." hour";
				else
					$hourstext = " ".$hours ." hours";
			}
			
			$diff = floor($diff / (60 * 60 * 24));
			if($diff == 1)
				$result = $diff ." day".$hourstext." ago";
			else
				$result = $diff ." days".$hourstext." ago";
		}
		else
		{
			$result = date('D, d M Y h:i A', $datetime);
		}
		
		return $result;
	}
	
	function GetShortDateTime($stringdatetime)
	{
		$result = "";
		date_default_timezone_set('UTC');
		$datetime = strtotime($stringdatetime);
		$currenttime = mktime();
		$diff = $currenttime - $datetime;
		
		if($diff < 60)
		{
			if($diff == 1)
				$result = $diff ." second ago";
			else
				$result = $diff ." seconds ago";
		}
		elseif($diff < (60 * 60))
		{
			$diff = floor($diff / 60);
			if($diff == 1)
				$result = $diff ." minute ago";
			else
				$result = $diff ." minutes ago";
		}
		elseif($diff < (60 * 60 * 24))
		{
			$minutes = $diff % (60 * 60);
			$minutes = floor($minutes / 60);
			$minutestext = "";
			
			if($minutes > 0)
			{
				if($minutes == 1)
					$minutestext = " ".$minutes." minute";
				else
					$minutestext = " ".$minutes ." minutes";
			}
			
			$diff = floor($diff / (60 * 60));
			if($diff == 1)
				$result = $diff ." hour".$minutestext." ago";
			else
				$result = $diff ." hours".$minutestext." ago";
		}
		elseif($diff < (60 * 60 * 24 * 7))
		{
			$hours = $diff % (60 * 60 * 24);
			$hours = floor($hours / (60 * 60));
			$hourstext = "";
			
			if($hours > 0)
			{
				if($hours == 1)
					$hourstext = " ".$hours ." hour";
				else
					$hourstext = " ".$hours ." hours";
			}
			
			$diff = floor($diff / (60 * 60 * 24));
			if($diff == 1)
				$result = $diff ." day".$hourstext." ago";
			else
				$result = $diff ." days".$hourstext." ago";
		}
		else
		{
			$result = date('M d, Y', $datetime);
		}
		return $result;
	}
	
	function GetDateTimeCode($row)
	{
		$DateTimeCode = "";			
		if($row['Popular'] == 1)
			$DateTimeCode = 'Made popular about <strong>' . HelpingMethods::GetLongDateTime($row['PopDateTime']) . '</strong>';
		else 
			$DateTimeCode = 'Discovered about <strong>' . HelpingMethods::GetLongDateTime($row['StoryDateTime']) . '</strong>';
			
		return $DateTimeCode;
	}
	
	function PrepareQuery($ChannelID, $RegionID, $CategoryID, $offSet, $resultsPerPage, $TimeSpan, $socialmediatype, $type)
	{
		$Query = "";
		
		if($type == "popular")
		{
			if($TimeSpan == "recent")
				$Query = HelpingDBMethods::PrepareRecentPopularQuery($ChannelID, $RegionID, $CategoryID, $offSet, $resultsPerPage, $TimeSpan, $socialmediatype);
			else
				$Query = HelpingDBMethods::PrepareTimeSpanPopularQuery($ChannelID, $RegionID, $CategoryID, $offSet, $resultsPerPage, $TimeSpan, $socialmediatype);	
		}
		else
		{
			if($TimeSpan == "recent")
				$Query = HelpingDBMethods::PrepareTimeSpanPerspectiveQuery($ChannelID, $RegionID, $CategoryID, $offSet, $resultsPerPage, "3 HOUR", $socialmediatype);
			else
				$Query = HelpingDBMethods::PrepareTimeSpanPerspectiveQuery($ChannelID, $RegionID, $CategoryID, $offSet, $resultsPerPage, $TimeSpan, $socialmediatype);
			
		}
		
		return $Query;
	}
	
	function PrepareSearchQuery($ChannelID, $RegionID, $CategoryID, $offSet, $resultsPerPage, $TimeSpan, $socialmediatype, $searchQuery, $searchType)	
	{
		$Query = "";
		
		if($searchType == "popular")
		{
			$Query = HelpingDBMethods::PreparePopularSearchQuery($ChannelID, $RegionID, $CategoryID, $offSet, $resultsPerPage, $TimeSpan, $socialmediatype, $searchQuery);
		}
		else if($searchType == "latest")
		{
			$Query = HelpingDBMethods::PrepareRecentSearchQuery($ChannelID, $RegionID, $CategoryID, $offSet, $resultsPerPage, $TimeSpan, $socialmediatype, $searchQuery);
		}
        else
        {
			$Query = HelpingDBMethods::PrepareBestMatchSearchQuery($ChannelID, $RegionID, $CategoryID, $offSet, $resultsPerPage, $TimeSpan, $socialmediatype, $searchQuery);
		}
		
		return $Query;
	}
	
	function SetStoryRowContent($row, $visible = true)
	{
		$display = ' style = "display:none;"';
		if($visible == true)
		{
			$display = '';
		}
		$result = "";
		$sourceURL = $row['StorySource'];
		$title = $row['StoryTitle'];
		$StoryID = $row['StoryID'];
		$DomainName = HelpingMethods::GetDomain($sourceURL);				
		$fbCount = HelpingDBMethods::GetFacebookCount($StoryID);//$row['FBSum'];
		$diggCount = HelpingDBMethods::GetDiggCount($StoryID);//$row['DiggSum'];
		$deliciousCount = HelpingDBMethods::GetDeliciousCount($StoryID);//$row['DBSum'];
		$twitterCount = 0;
		$commentCount = CommentsMethods::GetCommentCount($StoryID);
		$commentText = '<label id = "comment-link-count-' . $StoryID . '">' . $commentCount . "</label> Comments";
		if($commentCount == 0)
		{
			//$commentText = 'Post Comments';
		}
		$imageID = $row['ImageID'];
		$caption = "";
		$storywidth = 'style = "width:690px;"';
		$imgsrccode = '';
		if($imageID > 0)
		{
			$src = /*Settings::GetRootURL() .*/ HelpingDBMethods::GetImageData($imageID, $caption);
			//echo substr_count($src, "http://", 0, 7);
			if(substr_count($src, "http://", 0, 7) == 0)
			{
				$src = Settings::GetRootURL() . $src;
			}
			$imgsrccode = '<a href = "' . $sourceURL . '" target="_blank"><img alt="' . $caption . '" src="' . $src . '" class="prod-image" width = "75px" /></a>';
			$storywidth = 'style = "width:594px;"';
		}
		
		$DateTimeCode = HelpingMethods::GetDateTimeCode($row);
					
		$socialmediacount =  HelpingMethods::GetSocialMediaCountCode($fbCount, $diggCount, $deliciousCount);//(100, 100, 100);//
		
		$literalLikeDislike = HelpingMethods::GetLikeDislikeSection($StoryID);
								
		$reportLink = '<a href="#Report_Link_Box" class = "report-link" title = "" id = "reportLink' . $StoryID . '">Report</a>';
        $result = '<li style="padding-bottom:20px;"' . $display . ' id = "story' . $StoryID . '">
					<div class="product">
						' . $literalLikeDislike . '
						'.$imgsrccode.'
						<h3><a href="' . Settings::GetRootURL() . 'stumble/' . $StoryID . '" target="_blank">' . $title . '</a></h3>
						<p><a href = "' . Settings::GetRootURL() . 'pages/search.php?q=site:' . $DomainName . '">' . $DomainName . '</a> &#8212; '. HelpingMethods::GetLimitedText($row['StoryDescription'], 200) . ' <a id = "story-' . $StoryID . '-url" href="' . Settings::GetRootURL() . 'story/' . $row['StoryURL'] . '">(Read More)</a></p>
					</div>
					<div class = "clear"></div>
					<div class="social">
						'.$socialmediacount.'
						<a id = "comment-link-' . $StoryID . '" href="javascript:getComments(' . $StoryID . ', 0, 2, ' . $commentCount . ')" class="icon-comments">'. $commentText .'</a>
						' . $reportLink . '
						<span>'.$DateTimeCode.'</span>
					</div>
					<div id = "comments' . $StoryID . '" style = "display:none;">
						
					</div>
				</li>';
		return $result;
	}

	function GetSocialMediaCountCode($fbCount, $diggCount, $deliciousCount)
	{
		$fbcountscode = '';
		$diggcountscode = '';
		$deliciouscountcode = '';
		if($fbCount > 0)
		{             
			
			if($fbCount == 1)
			{
				$fbcountscode = '<em class="icon-facebook">' . $fbCount . ' Share</em>';
			}
			else
			{
				$fbcountscode = '<em class="icon-facebook">' . $fbCount . ' Shares</em>';
			}			
		}
		
		if($diggCount > 0)
		{
			if($diggCount == 1)
			{
				$diggcountscode = '<em class="icon-diggs">' . $diggCount . ' Digg</em>';
			}
			else
			{
				$diggcountscode = '<em class="icon-diggs">' . $diggCount . ' Diggs</em>';
			}			
		}
		if($deliciousCount > 0)
		{
			if($deliciousCount == 1)
			{
				$deliciouscountcode = '<em class="icon-delicious">' . $deliciousCount . ' Bookmark</em>';
			}
			else
			{
				$deliciouscountcode = '<em class="icon-delicious">' . $deliciousCount . ' Bookmarks</em>';
			}			
		}
		
		return '<p class="fr">'. $fbcountscode . $diggcountscode . $deliciouscountcode . '</p>';
	}
        	
	function GetSocialMediaCountCodeDetailed($diggCount, $deliciousCount, $fbShareCount, $fbLikeCount, $fbCommentCount)
	{
		$fbcountscode = '';
		$diggcountscode = '';
		$deliciouscountcode = '';
		if($fbShareCount > 0)
		{             

			if($fbShareCount == 1)
			{
				$fbcountscode .= '<em class="icon-facebook">' . $fbShareCount . ' Share&nbsp;</em>';
			}
			else
			{
				$fbcountscode .= '<em class="icon-facebook">' . $fbShareCount . ' Shares&nbsp;</em>';
			}			
		}
		
		if($fbLikeCount > 0)
		{             
			
			if($fbLikeCount == 1)
			{
				$fbcountscode .= '<em class="icon-facebook">' . $fbLikeCount . ' Like&nbsp;</em>';
			}
			else
			{
				$fbcountscode .= '<em class="icon-facebook">' . $fbLikeCount . ' Likes&nbsp;</em>';
			}			
		}
		
		if($fbCommentCount > 0)
		{             
			
			if($fbCommentCount == 1)
			{
				$fbcountscode .= '<em class="icon-facebook">' . $fbCommentCount . ' Comment&nbsp;</em>';
			}
			else
			{
				$fbcountscode .= '<em class="icon-facebook">' . $fbCommentCount . ' Comments&nbsp;</em>';
			}			
		}
		
		if($diggCount > 0)
		{
			if($diggCount == 1)
			{
				$diggcountscode = '<em class="icon-diggs">' . $diggCount . ' Digg</em>';
			}
			else
			{
				$diggcountscode = '<em class="icon-diggs">' . $diggCount . ' Diggs</em>';
			}			
		}
		if($deliciousCount > 0)
		{
			if($deliciousCount == 1)
			{
				$deliciouscountcode = '<em class="icon-delicious">' . $deliciousCount . ' Bookmark</em>';
			}
			else
			{
				$deliciouscountcode = '<em class="icon-delicious">' . $deliciousCount . ' Bookmarks</em>';
			}			
		}
		
		return '<p class="fr">'. $fbcountscode . $diggcountscode . $deliciouscountcode . '</p>';
	}
	
	function GetSocialMediaLinks()
	{
		$currentSM = RequestQueries::GetSocialMediaType();
		$categoryid = RequestQueries::GetCategory();
		$categoryURL = HelpingDBMethods::GetCategoryURL($categoryid);	
		
		$timespanURL = HelpingMethods::TranslateTimeSpanForURL(RequestQueries::GetTimeSpan());
		
		$result = "";
		$AllLink = "";
		$FBLink  = "";
		$DeliciousLink  = "";
		$DiggLink  = "";
		$allLinkActive = 'all-link';
		$fbLinkActive = 'fb-link';
		$diggLinkActive = 'digg-link';
		$deliciousLinkActive = 'delicious-link';
		switch(RequestQueries::GetSocialMediaType())
		{
			case 7;
				$allLinkActive = "all-link-selected";
				break;
			
			case 1;
				$fbLinkActive = "fb-link-selected";
				break;
			
			case 2;
				$deliciousLinkActive = "delicious-link-selected";
				break;	
				
			case 4;
				$diggLinkActive = "digg-link-selected";
				break;			
		}
		$AllLink = Settings::GetRootURL() . $categoryURL . $timespanURL;
		$FBLink  = Settings::GetRootURL() . $categoryURL . "fb/" . $timespanURL;
		$DeliciousLink  = Settings::GetRootURL() . $categoryURL . "delicious/" . $timespanURL;
		$DiggLink  = Settings::GetRootURL() . $categoryURL . "digg/" . $timespanURL;
		
		$result .= "<a href='" . $AllLink . "' class='" . $allLinkActive . "'>All</a>
					<a href='" . $FBLink . "' class='" . $fbLinkActive . "'></a>
					<a href='" . $DiggLink . "' class='" . $diggLinkActive . "'></a>
					<a href='" . $DeliciousLink . "' class='" . $deliciousLinkActive . "'></a>";
		return $result;
	}
	
	function GetTimeSpanLinks()
	{
		$result = "";
		
		$categoryid = RequestQueries::GetCategory();
		$categoryURL = HelpingDBMethods::GetCategoryURL($categoryid);
		
		$perspectiveURL = "";
		if(RequestQueries::GetType() == "perspective")
			$perspectiveURL = "perspective/";
		
		$smTypeURL = HelpingMethods::TranslateSocialMediaType(RequestQueries::GetSocialMediaType());		
		$TwelveHrLink = Settings::GetRootURL() . $categoryURL . $perspectiveURL. $smTypeURL;
		$TwentyFourHrLink = Settings::GetRootURL() . $categoryURL . $perspectiveURL. $smTypeURL . "24h/";
		$SevenDaysLink = Settings::GetRootURL() . $categoryURL . $perspectiveURL. $smTypeURL . "lastweek/";
		
		$TwelveHrLinkActive = '';
		$TwentyFourHrLinkActive = '';
		$SevenDaysLinkActive = '';		
		
		switch(RequestQueries::GetTimeSpan())
		{
			case "recent";
				$TwelveHrLinkActive = " class='active'";
				break;
			
			case "24h";
				$TwentyFourHrLinkActive = " class='active'";
				break;
			
			case "lastweek";
				$SevenDaysLinkActive = " class='active'";
				break;			
		}
		
		
		$result .= "<a href='".$TwelveHrLink."'".$TwelveHrLinkActive."><span class = 'blue-active-left'>&nbsp;</span><span class = 'blue-active-mid'>Recent</span><span class = 'blue-active-right'>&nbsp;</span></a> 
				<a href='".$TwentyFourHrLink."'".$TwentyFourHrLinkActive."><span class = 'blue-active-left'>&nbsp;</span><span class = 'blue-active-mid'>24 Hour</span><span class = 'blue-active-right'>&nbsp;</span></a>
				<a href='".$SevenDaysLink."'".$SevenDaysLinkActive."><span class = 'blue-active-left'>&nbsp;</span><span class = 'blue-active-mid'>7 Days</span><span class = 'blue-active-right'>&nbsp;</span></a>";
							
		
		return $result;
	}
	
	function GetChannelLinks()
	{
		$result = "";
		$channelid = RequestQueries::GetChannel();
		$channelURL = HelpingDBMethods::GetChannelURL($channelid);
		$categoryid = RequestQueries::GetCategory();
		$categoryURL = HelpingDBMethods::GetCategoryURL($categoryid);
		
		$perspectiveURL = "";
		if(RequestQueries::GetType() == "perspective")
			$perspectiveURL = "perspective/";
		
		$timespanURL = HelpingMethods::TranslateTimeSpanForURL(RequestQueries::GetTimeSpan());
            
        $NewsLink  = Settings::GetRootURL() . 'news/' . $categoryURL . $perspectiveURL. $timespanURL;
        $VideoLink = Settings::GetRootURL() . 'video/' . $categoryURL . $perspectiveURL. $timespanURL;
        $PhotoLink = Settings::GetRootURL() . 'photo/' . $categoryURL . $perspectiveURL. $timespanURL;
		
		$NewsLinkActive = '';
		$VideosLinkActive = '';
		$PhotosLinkActive = '';		
		
		switch($channelid)
		{
			case 1;
				$NewsLinkActive = " class='active'";
				break;
			
			case 2;
				$VideosLinkActive = " class='active'";
				break;
			
			case 3;
				$PhotosLinkActive = " class='active'";
				break;			
		}
		
		
		$result .= "<a href='".$NewsLink."'".$NewsLinkActive."><span class = 'blue-active-left'>&nbsp;</span><span class = 'blue-active-mid'>News</span><span class = 'blue-active-right'>&nbsp;</span></a> 
				<a href='".$VideoLink."'".$VideosLinkActive."><span class = 'blue-active-left'>&nbsp;</span><span class = 'blue-active-mid'>Videos</span><span class = 'blue-active-right'>&nbsp;</span></a>
				<a href='".$PhotoLink."'".$PhotosLinkActive."><span class = 'blue-active-left'>&nbsp;</span><span class = 'blue-active-mid'>Photos</span><span class = 'blue-active-right'>&nbsp;</span></a>";
		
		
		return $result;
	}
	
	function TranslateTimeSpanForURL($TimeSpan)
	{
		$result = "";		
		
		if($TimeSpan == "24hr")
		{
			$result = "24hr/";
		}
		if($TimeSpan == "lastweek")
		{
			$result = "lastweek/";
		}	
		
		return $result;
	}
	
	function TranslateSocialMediaType($typeID)
	{
		$result = "";
		switch($typeID)
		{
			case 1:
				$result = "fb/";
				break;				
			case 2:
				$result = "delicious/";
				break;
			case 4:
				$result = "digg/";
				break;
		}
		return $result;
	}
	
	function GetLimitedText($Text, $Limit)
	{
		$result = "";
		$Text = strip_tags($Text);
		if(strlen($Text) > $Limit)
		{
			$result = substr($Text, 0, $Limit) . '...';
		}
		else
		{
			$result = $Text;
		}
				
		return $result ;
	}
	
	function CleanString($string)
	{
		$t = preg_replace('/[^a-zA-Z0-9]/', ' ', $string);		
		$t = trim($t);
		$t = preg_replace('/ +/', ' ', $t);
		return $t;
	}
	
	function GetFormattedUrl($url)
	{		
		$index = stripos($url, "?", 0);
		
		if($index != false)
		{
			$innerindex = stripos($url, "?id=", 0);
			if($innerindex != false)
			{
				$pos = stripos($url, "&", 0);
				if($pos >= 0)
				{
					$url = substr($url, 0, $pos);
				}
			}
			else
			{
				$url = substr($url, 0, $index);
			}
		}
		
		return $url;		
	}

    static function GetCurrentCategoryName()
         {
            $CategoryID = RequestQueries::GetCategory();
            $Result = "All";

            switch($CategoryID)
            {
                case 1:
                    $Result = "World";
                    break;

                case 2:
                    $Result = "Business";
                    break;

                case 3:
                    $Result = "Entertainment";
                    break;

                case 4:
                    $Result = "Sports";
                    break;

                case 5:
                    $Result = "Technology";
                    break;

                case 6:
                    $Result = "Science";
                    break;

                case 7:
                    $Result = "Offbeat";
                    break;
            }

            return $Result;
        }

    static function GetCategoryName($CategoryID)
        {
            $Result = "All";

            switch($CategoryID)
            {
                case 1:
                    $Result = "World";
                    break;

                case 2:
                    $Result = "Business";
                    break;

                case 3:
                    $Result = "Entertainment";
                    break;

                case 4:
                    $Result = "Sports";
                    break;

                case 5:
                    $Result = "Technology";
                    break;

                case 6:
                    $Result = "Science";
                    break;

                case 7:
                    $Result = "Offbeat";
                    break;
            }

            return $Result;
        }
        
    function GetLikeDislikeSection($StoryID)
    {
		$DislikeCount = "";
		$LikeCount = HelpingDBMethods::GetLikeDislikeCount($StoryID, $DislikeCount);
		$isMemberLikeDisliked = false;
		if($GLOBALS['user']->is_loaded())
		{
			$isMemberLikeDisliked = HelpingDBMethods::GetisMemberLikeDisliked($StoryID, $GLOBALS['user']->userID);
		}
		
		$forVoteHyperlink = '';
		$againstVoteHyperlink = '';
		$likeDislikeCssClass = '';
		if ($isMemberLikeDisliked == false)
		{
			$likeDislikeCssClass = "LikeDislike";
			if($GLOBALS['user']->is_loaded())
			{
				$forVoteHyperlink = "<a href='javascript:postvote(" . $StoryID . ", true);'>Like it</a>";
				$againstVoteHyperlink = "<a href='javascript:postvote(" . $StoryID . ", false);'>Dislike it</a>";
			}
			else
			{
				$forVoteHyperlink = "<a href='#Login_SignUp_Box' class='login'  title='Login Or Sign Up to Vote'>Like it</a>";
				$againstVoteHyperlink = "<a href='#Login_SignUp_Box' class='login'  title='Login Or Sign Up to Vote'>Dislike it</a>";
			}
			
		}
		else 
		{
			$likeDislikeCssClass = "LikeDislike-disabled";
			$forVoteHyperlink = "Like it";
			$againstVoteHyperlink = "Dislike it";
		}
		$literalLikeDislike =  "<div class='" . $likeDislikeCssClass . "' id ='LikeDislike" . $StoryID . "'>
									<div class='Like' id = 'divLikeIt" . $StoryID . "'>" . $forVoteHyperlink . "</div>
									<div class='Count' id = 'divLikeItCount" . $StoryID . "'>" . $LikeCount . "</div> 
									<div class='CountDislike' id = 'divDisLikeItCount" . $StoryID . "'>" . $DislikeCount . "</div> 
									<div class='Dislike' id = 'divDisLikeIt" . $StoryID . "'>" . $againstVoteHyperlink . "</div>                          
								</div>";
		return $literalLikeDislike;
	}
}

?>