<?php 
class Settings
{
	private static $_DBServerName = "localhost";
	private static $_DBName = "admin5_connichiwah";
	private static $_UserName = "admin5_admin5";
	private static $_DBPassword = "admin5_admin5";
	//private static $_SecretKey = "12";
	function GetRootURL()
	{
		return "/connichiwah/";
	}
	
	function GetDatabaseName()
	{
		return Settings::$_DBName;
	}
	
	function ConnectDB()
	{
		$connection = mysql_connect(Settings::$_DBServerName, Settings::$_UserName, Settings::$_DBPassword)or die(mysql_error()); 	
		return $connection;
	}
	
	function isValidSecretKey($key)
	{
		if($key == Settings::$_SecretKey)
		{
			return true;			
		}
		else
		{
			return false;
		}
	}	
}
?>