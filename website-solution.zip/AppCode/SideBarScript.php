<?php
require_once 'ApplicationSettings.php';
require_once 'HelpingDBMethods.php';
require_once 'HelpingMethods.php';
require_once 'RequestQuery.php';

$databaseName = Settings::GetDatabaseName();
$rootURL = Settings::GetRootURL();

class SideBar
{
	function GetRegionsMenu($parentID, $currentLevel, $visible = true, $currentType = 'popular')
	{
		$maxLevel = 2;
		$result = "";
		$display = '';
		if(!$visible)
		{
			$display = ' style = "display:none;"';
		}
		if($currentLevel <= $maxLevel)
		{
			$QueryResult =  mysql_query("SELECT * FROM tblregion WHERE (ParentID = $parentID)")or die(mysql_error());
			$row = mysql_fetch_array($QueryResult);
			if($row != false)
			{
				if($currentLevel == 1)
				{
					$result .= '<ul id = "region-links" class="main-cats" ' . $display . '>';
					//$result .= sprintf("<li class='expanded'><h3><a href='%1\$s'>%2\$s</a></h3>", $GLOBALS['rootURL']. '', "All");
				}
				else
				{
					$result .= '<ul>';
				}
				while($row != false)
				{
					$thisLinkClass = 'sm-link';
					if($currentType == 'region' && $row["RegionURL"] == RequestQueries::GetRegion())
					{
						$thisLinkClass = 'sm-link-selected';
					}
					if($currentLevel == 1)
					{
						$class = "expanded";
						$children = SideBar::GetRegionsMenu($row['RegionID'], $currentLevel + 1, true, $currentType);
						if($children == "")
						{
							$class = '';
						}						
						$result .= sprintf("<li class='%3\$s %4\$s'><h3><a href='%1\$s'>%2\$s</a></h3>", $GLOBALS['rootURL'] . "region/" . $row["RegionURL"] . "/", ucfirst($row["RegionName"]), $class, $thisLinkClass);
						$result .= $children;
					}
					else
					{
						$result .= sprintf("<li class='%3\$s'><a href='%1\$s'>%2\$s</a>", $GLOBALS['rootURL'] . "region/" . $row["RegionURL"] . "/", ucfirst($row["RegionName"]), $thisLinkClass);
						$result .= SideBar::GetRegionsMenu($row['RegionID'], $currentLevel + 1, true, $currentType);
					}
					$result .= '</li>';
					$row = mysql_fetch_array($QueryResult);
				}
				$result .= '</ul>';
			}
		}				
		return $result;
	}
	
	function GetPopularMenu($parentID, $currentLevel, $visible = true, $currentType = 'popular')
	{
		$maxLevel = 2;
		$result = "";
		$display = '';
		$currentSM = HelpingMethods::TranslateSocialMediaType(RequestQueries::GetSocialMediaType());
		$timespanURL = HelpingMethods::TranslateTimeSpanForURL(RequestQueries::GetTimeSpan());
		$currentType = RequestQueries::GetType();
		if(!$visible)
		{
			$display = ' style = "display:none;"';
		}
		if($currentLevel <= $maxLevel)
		{
			$QueryResult =  mysql_query("SELECT * FROM tblcategory WHERE (ParentID = $parentID) ORDER BY CategoryName")or die(mysql_error());
			$row = mysql_fetch_array($QueryResult);
			if($row != false)
			{
				if($currentLevel == 1)
				{
					//$result .= '<ul id = "region-links" class="main-cats" ' . $display . '>';
					//$result .= sprintf("<li class='expanded'><h3><a href='%1\$s'>%2\$s</a></h3>", $GLOBALS['rootURL']. '', "All");
				}
				else
				{
					$result .= '<ul>';
				}
				while($row != false)
				{
					$thisLinkClass = 'sm-link';
					$url = Settings::GetRootURL() . $row["CategoryURL"] . '/'  . $currentSM .  $timespanURL;
					if($currentType == 'popular' && $row["CategoryID"] == RequestQueries::GetCategory())
					{
						$thisLinkClass = 'sm-link-selected';
					}
					if($currentLevel == 1)
					{
						$class = "expanded";
						$children = SideBar::GetPopularMenu($row['CategoryID'], $currentLevel + 1, true, $currentType);
						if($children == "")
						{
							$class = '';
						}												
						$result .= sprintf("<li class='%3\$s'><h3 class = '%4\$s'><a href='%1\$s'>%2\$s</a></h3>", $url, ucfirst($row["CategoryName"]), $class, $thisLinkClass);
						$result .= $children;
					}
					else
					{
						$result .= sprintf("<li class='%3\$s'><a href='%1\$s'>%2\$s</a>", $url, ucfirst($row["CategoryName"]), $thisLinkClass);
						$result .= SideBar::GetPopularMenu($row['CategoryID'], $currentLevel + 1, true, $currentType);
					}
					$result .= '</li>';
					$row = mysql_fetch_array($QueryResult);
				}
				if($currentLevel == 1)
				{
					
				}
				else
				{
					$result .= '</ul>';
				}
				
			}
		}				
		return $result;
	}
	
	function GetPerspectiveMenu($parentID, $currentLevel, $visible = true, $currentType = 'perspective')
	{
		$maxLevel = 2;
		$result = "";
		$display = '';
		$currentSM = HelpingMethods::TranslateSocialMediaType(RequestQueries::GetSocialMediaType());
		$timespanURL = HelpingMethods::TranslateTimeSpanForURL(RequestQueries::GetTimeSpan());
		$currentType = RequestQueries::GetType();
		if(!$visible)
		{
			$display = ' style = "display:none;"';
		}
		if($currentLevel <= $maxLevel)
		{
			$QueryResult =  mysql_query("SELECT * FROM tblcategory WHERE (ParentID = $parentID) ORDER BY CategoryName")or die(mysql_error());
			$row = mysql_fetch_array($QueryResult);
			if($row != false)
			{
				if($currentLevel == 1)
				{
					//$result .= '<ul id = "region-links" class="main-cats" ' . $display . '>';
					//$result .= sprintf("<li class='expanded'><h3><a href='%1\$s'>%2\$s</a></h3>", $GLOBALS['rootURL']. '', "All");
				}
				else
				{
					$result .= '<ul>';
				}
				while($row != false)
				{
					$thisLinkClass = 'sm-link';
					$url = Settings::GetRootURL() . $row["CategoryURL"] . '/' . "perspective/" . $currentSM .  $timespanURL;
					if($currentType == 'perspective' && $row["CategoryID"] == RequestQueries::GetCategory())
					{
						$thisLinkClass = 'sm-link-selected';
					}
					if($currentLevel == 1)
					{
						$class = "expanded";
						$children = SideBar::GetPerspectiveMenu($row['CategoryID'], $currentLevel + 1, true, $currentType);
						if($children == "")
						{
							$class = '';
						}												
						$result .= sprintf("<li class='%3\$s'><h3 class = '%4\$s'><a href='%1\$s'>%2\$s</a></h3>", $url, ucfirst($row["CategoryName"]), $class, $thisLinkClass);
						$result .= $children;
					}
					else
					{
						$result .= sprintf("<li class='%3\$s'><a href='%1\$s'>%2\$s</a>", $url, ucfirst($row["CategoryName"]), $thisLinkClass);
						$result .= SideBar::GetPerspectiveMenu($row['CategoryID'], $currentLevel + 1, true, $currentType);
					}
					$result .= '</li>';
					$row = mysql_fetch_array($QueryResult);
				}
				if($currentLevel == 1)
				{
					
				}
				else
				{
					$result .= '</ul>';
				}
				
			}
		}				
		return $result;
	}
	
	function GetTopTen()
	{
		$Now = time();
		$CurrentGMTTime = gmdate("Y-m-d H:i:s", $Now);

                $CategoryQuery = "";
                $CategoryID = RequestQueries::GetCategory();
                if($CategoryID > 0)
		{
			$CategoryQuery = " INNER JOIN tblstorycategory ON tblstory.StoryID = tblstorycategory.StoryID AND tblstorycategory.CategoryID = " . $CategoryID;
		}

		$Query = "SELECT tblstory.*,(SELECT COALESCE(SUM(FBTotalCount), 0) FROM tblfacebook WHERE (tblfacebook.StoryID = tblstory.StoryID) AND (FBDateTime >= ('".$CurrentGMTTime."'-INTERVAL 7 Day))) AS FBSum,(SELECT COUNT(DeliciousStoryID) FROM tbldeliciousbookmarks WHERE (tbldeliciousbookmarks.DeliciousStoryID = tblstory.DeliciousStoryID) AND (DeliciousDateTime >= ('".$CurrentGMTTime."'-INTERVAL 7 Day))) AS DBSum,(SELECT COUNT(DiggStoryID) FROM tbldigg WHERE (tbldigg.DiggStoryID = tblstory.DiggStoryID) AND (DiggDateTime >= ('".$CurrentGMTTime."'-INTERVAL 7 Day))) AS DiggSum FROM tblstory " . $CategoryQuery . " WHERE (StoryDateTime >= ('".$CurrentGMTTime."'-INTERVAL 7 Day)) ORDER BY ((FBSum * 0.5)+(DBSum * 25)+(DiggSum * 6)) DESC LIMIT 0, 10";
		
		$result = "";
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		if($row != false)
		{
			$result .= '<ul class="top-in-all">';
			while($row != false)
			{
				$imgsrccode = "";//"<img alt='' src='images/website/image-sidebar.jpg' />";
				$imageID = $row['ImageID'];
				if($imageID >0)
				{
					$caption = "";
					$imgsrc = HelpingDBMethods::GetImageData($imageID, $caption);
					if(substr_count($imgsrc, "http://", 0, 7) == 0)
					{
						$imgsrc = Settings::GetRootURL() . $imgsrc;
					}
					$imgsrccode = '<a href = "' . $row["StorySource"] . '" target="_blank"><img alt="' . $caption . '" src="' . $imgsrc . '" width="32px" /></a>';
				}
				$result .= sprintf("<li>%4\$s<p><a href='%1\$s' target = '_blank' title = '%3\$s'>%2\$s</a></p></li>", $row["StorySource"], HelpingMethods::GetLimitedText($row["StoryTitle"], 55), HelpingMethods::CleanString($row["StoryTitle"]), $imgsrccode);
				$row = mysql_fetch_array($QueryResult);
			}
			$result .= '</ul>';
		}
		
		return $result;
	}
	
	function GetSocialMediaLinks()
	{
		$currentSM = RequestQueries::GetSocialMediaType();
		$categoryid = RequestQueries::GetCategory();
		$categoryURL = HelpingDBMethods::GetCategoryURL($categoryid);
		$currentType = RequestQueries::GetType();
		
		$timespanURL = HelpingMethods::TranslateTimeSpanForURL(RequestQueries::GetTimeSpan());
		
		$result = "";
		$AllLink = "";
		$FBLink  = "";
		$DeliciousLink  = "";
		$DiggLink  = "";
		$allLinkActive = 'sm-link';
		$fbLinkActive = 'sm-link';
		$diggLinkActive = 'sm-link';
		$deliciousLinkActive = 'sm-link';
		
		$allPerspectiveLinkActive = 'sm-link';
		$fbPerspectiveLinkActive = 'sm-link';
		$diggPerspectiveLinkActive = 'sm-link';
		$deliciousPerspectiveLinkActive = 'sm-link';
		
		$popularClass = "";
		$perspectiveClass = "";
		$populardisplay = "";
		$perspectivedisplay = "";
		
		if($currentType == "perspective")
		{
			$popularClass = "expandable";
			$perspectiveClass = "collapseable";
			$populardisplay = " style = 'display:none;'";
			$perspectivedisplay = "";
			switch($currentSM)
			{
				case 7;
					$allPerspectiveLinkActive = "sm-link-selected";
					break;
				
				case 1;
					$fbPerspectiveLinkActive = "sm-link-selected";
					break;
				
				case 2;
					$deliciousPerspectiveLinkActive = "sm-link-selected";
					break;	
				
				case 4;
					$diggPerspectiveLinkActive = "sm-link-selected";
					break;			
			}
		}
		else
		{
			$popularClass = "collapseable";
			$perspectiveClass = "expandable";
			$populardisplay = "";
			$perspectivedisplay = " style = 'display:none;'";
			switch($currentSM)
			{
				case 7;
					$allLinkActive = "sm-link-selected";
					break;
				
				case 1;
					$fbLinkActive = "sm-link-selected";
					break;
				
				case 2;
					$deliciousLinkActive = "sm-link-selected";
					break;	
				
				case 4;
					$diggLinkActive = "sm-link-selected";
					break;			
			}
		}		
				
		$AllLink = Settings::GetRootURL() . $categoryURL .  $timespanURL;
		$FBLink  = Settings::GetRootURL() . $categoryURL .  "fb/" . $timespanURL;
		$DeliciousLink  = Settings::GetRootURL() . $categoryURL . "delicious/" . $timespanURL;
		$DiggLink  = Settings::GetRootURL() . $categoryURL .  "digg/" . $timespanURL;
		
		$perspectiveURL = "perspective/";
		$AllPerspectiveLink = Settings::GetRootURL() . $categoryURL . $perspectiveURL. $timespanURL;
		$FBPerspectiveLink  = Settings::GetRootURL() . $categoryURL . $perspectiveURL. "fb/" . $timespanURL;
		$DeliciousPerspectiveLink  = Settings::GetRootURL() . $categoryURL . $perspectiveURL. "delicious/" . $timespanURL;
		$DiggPerspectiveLink  = Settings::GetRootURL() . $categoryURL . $perspectiveURL. "digg/" . $timespanURL;
		
		$result .= "<h2 id = 'heading-pop' class='" . $popularClass . "' onclick = 'swapdisplay(\"heading-pop\", \"heading-per\", \"popular-links\", \"perspective-links\")'><span>Popular</span></h2>
					<ul class='main-cats' id = 'popular-links' " . $populardisplay . ">
						<li class='" . $allLinkActive . "'><h3><a href='" . $AllLink . "'><span  class = 'all-link-icon'>All</span></a></h3></li>
						<li class='" . $fbLinkActive . "'><h3><a href='" . $FBLink . "'><span  class = 'fb-link-icon'>Facebook</span></a></h3></li>
						<li class='" . $diggLinkActive . "'><h3><a href='" . $DiggLink . "'><span  class = 'digg-link-icon'>Digg</span></a></h3></li>
						<li class='" . $deliciousLinkActive . "'><h3><a href='" . $DeliciousLink . "'><span  class = 'delicious-link-icon'>Delicious</span></a></h3></li>
					</ul>
				
					<h2 id = 'heading-per' class='" . $perspectiveClass . "' style = 'margin-top:10px;' onclick = 'swapdisplay(\"heading-per\", \"heading-pop\", \"perspective-links\", \"popular-links\")'><span>Perspective</span></h2>
					<ul class='main-cats' id = 'perspective-links' " . $perspectivedisplay . ">
						<li class='" . $allPerspectiveLinkActive . "'><h3><a href='" . $AllPerspectiveLink . "'><span  class = 'all-link-icon'>All</span></a></h3></li>
						<li class='" . $fbPerspectiveLinkActive . "'><h3><a href='" . $FBPerspectiveLink . "'><span  class = 'fb-link-icon'>Facebook</span></a></h3></li>
						<li class='" . $diggPerspectiveLinkActive . "'><h3><a href='" . $DiggPerspectiveLink . "'><span  class = 'digg-link-icon'>Digg</span></a></h3></li>
						<li class='" . $deliciousPerspectiveLinkActive . "'><h3><a href='" . $DeliciousPerspectiveLink . "'><span  class = 'delicious-link-icon'>Delicious</span></a></h3></li>
					</ul>";
		return $result;
	}
	
	function GetBrowseLinks()
	{
		$currentSM = HelpingMethods::TranslateSocialMediaType(RequestQueries::GetSocialMediaType());
		//$categoryURL = HelpingDBMethods::GetCategoryURL(RequestQueries::GetCategory());
		$currentType = RequestQueries::GetType();
		
		$timespanURL = HelpingMethods::TranslateTimeSpanForURL(RequestQueries::GetTimeSpan());
		
		$result = "";		
		
		$linkClass = 'sm-link';//sm-link-selected 
		$headerClassPopular = 'expandable'; //collapseable
		$headerClassPerspective = 'expandable'; //collapseable
		$headerClassRegions = 'expandable'; //collapseable
		$populardisplay = ' style = "display:none;"';
		$perspectivedisplay = ' style = "display:none;"';
		$regionDisplay = false;
		
		if($currentType == "popular")
		{
			$headerClassPopular = 'collapseable';
			$populardisplay = '';
		}
		elseif($currentType == "perspective")
		{
			$headerClassPerspective = 'collapseable';
			$perspectivedisplay = '';
		}
		elseif($currentType == "region")
		{
			$headerClassPerspective = 'collapseable';
			$regionDisplay = true;
		}
		// Set Popular And Rerspective Category Links
		$popularLinks = "<h2 id = 'heading-pop' class='" . $headerClassPopular . "' onclick = 'swapdisplay(\"heading-pop\")'><span>Popular</span></h2>
						 <ul class='main-cats' id = 'popular-links' " . $populardisplay . ">";
		$perspectiveLinks = "<h2 id = 'heading-per' class='" . $headerClassPerspective . "' style = 'margin-top:10px;' onclick = 'swapdisplay(\"heading-per\")'><span>Perspective</span></h2>
							 <ul class='main-cats' id = 'perspective-links' " . $perspectivedisplay . ">";
		//============================ Nested Category Code =========================================//
		$thisLinkClass = $linkClass;
		if($currentType == "popular" && RequestQueries::GetCategory() == 0)
		{
			$thisLinkClass = 'sm-link-selected';
		}
		$urlpopular = Settings::GetRootURL() . $currentSM .  $timespanURL;
		$popularLinks .= "<li><h3 class='" . $thisLinkClass . "'><a href='" . $urlpopular . "'>All</a></h3></li>";
		$popularLinks .= SideBar::GetPopularMenu(0, 1, true, "popular");
		$thisLinkClass = $linkClass;
		if($currentType == "perspective" && RequestQueries::GetCategory() == 0)
		{
			$thisLinkClass = 'sm-link-selected';
		}
		$urlperspective = Settings::GetRootURL() . "perspective/" . $currentSM .  $timespanURL;
		$perspectiveLinks .= "<li><h3  class='" . $thisLinkClass . "'><a href='" . $urlperspective . "'>All</a></h3></li>";
		$perspectiveLinks .= SideBar::GetPerspectiveMenu(0, 1, true, "perspective");
		//============================ Nested Category Code =========================================//
		//======================== Non Nested Category Code =========================================//
		/*$categories = HelpingDBMethods::GetCategories(true);
		foreach($categories as $categoryName=>$catURL)
		{
			$thisLinkClass = $linkClass;
			if($currentType == "popular" && $categoryURL == $catURL)
			{
				$thisLinkClass = 'bg-gray';
			}
			
			$urlpopular = Settings::GetRootURL() . $catURL  . $currentSM .  $timespanURL;
			$popularLinks .= "<li><h3 class='" . $thisLinkClass . "'><a href='" . $urlpopular . "'>" . $categoryName . "</a></h3></li>";
			$thisLinkClass = $linkClass;
			if($currentType == "perspective" && $categoryURL == $catURL)
			{
				$thisLinkClass = 'bg-gray';
			}
			$urlperspective = Settings::GetRootURL() . $catURL . "perspective/" . $currentSM .  $timespanURL;
			$perspectiveLinks .= "<li><h3  class='" . $thisLinkClass . "'><a href='" . $urlperspective . "'>" . $categoryName . "</a></h3></li>";
		}*/
		//======================== Non Nested Category Code =========================================//
		$popularLinks .= '</ul>';
		$perspectiveLinks .= '</ul>';
		// Set Region Links
		$regionLinks = "<h2 id = 'heading-region' class='" . $headerClassRegions . "' style = 'margin-top:10px;' onclick = 'swapdisplay(\"heading-region\")'><span>Regions</span></h2>";
		$regionLinks .= SideBar::GetRegionsMenu(0, 1, $regionDisplay, $currentType);
		//echo $currentType . '		' . RequestQueries::GetRegion();		
		$result = $popularLinks . $perspectiveLinks;// . $regionLinks;
		///////////////=======================================================================/////////////////////////
		
		return $result;
	}
	
	function GetPopularSearches($limit)
	{
		$result = "";
		$QueryResult =  mysql_query("SELECT * FROM tblpopularsearches ORDER BY Count DESC LIMIT 0, $limit")or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		if($row != false)
		{
			$result .= '<ul class="main-cats">';
			while($row != false)
			{				
				$result .= sprintf("<li><h3><a href='%1\$s'>%2\$s<span style = 'float:right;'></span></a></h3></li>", Settings::GetRootURL() . 'pages/search.php?q=' . $row['SearchText'], HelpingMethods::GetLimitedText($row["SearchText"], 20), $row["Count"]);
				$row = mysql_fetch_array($QueryResult);
			}
			$result .= '</ul>';
		}
		
		return $result;
	}
}
?>