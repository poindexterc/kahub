<?php
require_once 'ApplicationSettings.php';
require_once 'HelpingDBMethods.php';
require_once 'MemberDBMethods.php';
class ConnichiwahUI
{	
	function UIHoverboxShare($text_selected, $url)
	{
		$rooturl = Settings::GetRootURL();
		$result = <<<HTML
				<div class="box-without-left-border">
                    
                    <div class="box-without-left-border-top"></div>
                    <div class="box-without-left-border-mid wrapper">
                        <textarea type="text" class="white-box-170" name = "commentstext"></textarea>
                        
                        <input type="submit" value="Share" class="share-btn" name = "submit"/> 
                        <a href = "{$rooturl}service/comment-service.php?type=UI.Hoverbox.Share&text={$text_selected}&url={$url}&lock=1" ><img alt="" src="images/uni-lock.jpg" class="lock"/></a>
                    </div>
                    <div class="box-without-left-border-bot"></div>
                        
                </div>
HTML;
		return $result;
	}
	
	function UIFace($text_selected, $url)
	{
		$result = '<div class="box-29">';$MemberImage = '';
		$storyID = HelpingDBMethods::GetStoryID($url);
		$Query = "SELECT DISTINCT MemberID FROM tbl_comments WHERE (Comment_Associated_Text = '$text_selected') AND (StoryID = $storyID)";
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		while($row!=false)
		{
			$MemberID = $row['MemberID'];
			$MemberName = MemberDBMethods::GetUserName($MemberID);
			$ImageID = 0;
			$MemberImage = Settings::GetRootURL() . HelpingDBMethods::GetImageData($ImageID);
			$result .= <<<HTML
			        <div class="box-29-top"></div>
                    <div class="box-29-mid"><img src = '{$MemberImage}' style = "padding:0px; width:25px;" /></div>
                    <div class="box-29-bot"></div>
HTML;
			$row = mysql_fetch_array($QueryResult);
		}
		$result .= '</div>';
		
		return $result;
	}
	
	function UIHoverboxComments($text_selected, $url)
	{
		$rooturl = Settings::GetRootURL();
		$result = '<div class="box-trust">
						<div class="box-trust-top"></div>
						<div class="box-trust-mid">';
		$storyID = HelpingDBMethods::GetStoryID($url);
		$Query = "SELECT * FROM tbl_comments WHERE (Comment_Associated_Text = '$text_selected') AND (StoryID = $storyID)";
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		while($row!=false)
		{
			$MemberID = $row['MemberID'];
			$MemberName = MemberDBMethods::GetUserName($MemberID);
			$ImageID = 0;
			$MemberImage = $rooturl . HelpingDBMethods::GetImageData($ImageID);
			$CommentText = $row['Comment_Text'];
			$CommentID = $row['CommentID'];
			$result .= <<<HTML
					
							<div style = "padding:5px 0px 5px 0px;">
								<p class="fr"><span>{$MemberName}</span> said {$CommentText}</p>
								<img alt="" src="$MemberImage" class="bdr"/>
								<a href="#" class="trust-btn">Trust</a>
								
								<a href="#"><img alt="" src="images/uni-ok.png" class="middle"/></a>
								<a href="{$rooturl}service/comment-service.php?type=UI.Hoverbox.Reply&text={$text_selected}&url={$url}&commentid={$CommentID}"><img alt="" src="images/uni-reply.png" class="middle"/></a>
	                        </div>
	                        
							
HTML;
			$row = mysql_fetch_array($QueryResult);
		}
		
		$result .= '		
															   
						</div>
						<div class="box-trust-bot"></div>
	                    
					</div>';
		return $result;
	}
	
	function AllComments()
	{
		$roughText = "alumni,admissions,composed,The Masters degrees include Law and Juris Doctor,Bicycles are convenient";
		$result = <<<HTML
				<script type = "text/javascript">
					var roughText = "{$roughText}";
					var myFunction = new function() 
					{
						//alert("wowxcvb");					   
					    return "dg";
					}
					
				</script>
HTML;
		return $result;
	}
	
	function UIPrivacy($text_selected, $url)
	{
		$rooturl = Settings::GetRootURL();
		return <<<HTML
			<div class="share-with">
                
                    <div class="share-with-top"></div>
                    <div class="share-with-mid">
                        <a href="{$rooturl}service/comment-service.php?type=UI.Hoverbox.Share&text={$text_selected}&url={$url}&lock=2" class="red-btn-85">Share with<br /> a Source</a>
                        <a href="{$rooturl}service/comment-service.php?type=UI.Hoverbox.Share&text={$text_selected}&url={$url}" class="red-btn-85">Share with<br /> your Network</a>
                    </div>
                    <div class="share-with-bot"></div>
                
                </div>
HTML;
	}
	
	function UIPrivacySourceSelection($text_selected, $url)
	{
		$rooturl = Settings::GetRootURL();
		return <<<HTML
			<div class="box-192">
                    
                    <div class="box-192-top"></div>
                    <div class="box-192-mid">
                        
                        <input type="text" value="Type the name of a source	" class="white-box-172" />
                        
                        <!--<input type="submit" value="Okay, done" class="okay-done" />-->
                        <a href="{$rooturl}service/comment-service.php?type=UI.Hoverbox.Share&text={$text_selected}&url={$url}" class="okay-done">Okay, done</a>
                    </div>
                    <div class="box-192-bot"></div>
                    
                </div>
HTML;
	}
	
	function UIHoverboxReply($text_selected, $url, $CommentID)
	{
		$rooturl = Settings::GetRootURL();
		$result = '<div class="box-191">
                    <div class="box-192-top"></div>	
                    <div class="box-191-mid wrapper">';
		$Query = "SELECT * FROM tbl_comments WHERE (CommentID = '$CommentID')";
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		if($row!=false)
		{
			$MemberID = $row['MemberID'];
			$MemberName = MemberDBMethods::GetUserName($MemberID);
			$ImageID = 0;
			$MemberImage = $rooturl . HelpingDBMethods::GetImageData($ImageID);
			$CommentText = $row['Comment_Text'];
			$CurrentMemberImage = $rooturl . HelpingDBMethods::GetImageData(0);
			$result .= <<<HTML
                        <p><span>{$MemberName}</span> said {$CommentText}</p>                        
                        <img alt="" src="{$MemberImage}" width = "32px" />                        
                        <div class="cl"></div>                        
                        <img alt="" src="{$CurrentMemberImage}" />                        
                        <textarea type="text" name = "commentstext" class="white-box-140"></textarea>                       
                        <input type="submit" value="Post Reply" class="post-reply-btn" name = "submit" />
HTML;
		}
		$result .= ' </div>
                     <div class="box-191-bot"></div>
                    
                </div>';
		return $result;
	}
}

?>