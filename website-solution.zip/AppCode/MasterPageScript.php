<?php
require_once 'access.class.php';
$user = new flexibleAccess();
require_once 'ApplicationSettings.php';
require_once 'HelpingDBMethods.php';
require_once 'RequestQuery.php';
require_once 'MemberDBMethods.php';
$databaseName = Settings::GetDatabaseName();
$rootURL = Settings::GetRootURL();
$LiteralRegionLinks = "";
$LiteralCategoryLinks = "";
class MasterPage
{
	function GetHeadScript()
	{	
		$result = <<<Content
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
					    
			<!--<link type="text/css" rel="stylesheet" href="{$GLOBALS['rootURL']}css/style.css" />-->
			<script type='text/javascript' src="{$GLOBALS['rootURL']}script/jquery-latest.min.js"></script>
		    <script src="{$GLOBALS['rootURL']}script/ajaxreq.js" type="text/javascript"></script>
		    <script src="{$GLOBALS['rootURL']}script/common.js" type="text/javascript"></script> 
		                                                                                        	
			<!--[if IE 6]>
			<script src="{$GLOBALS['rootURL']}js/belated.js" type="text/javascript"></script>
			<![endif]-->
		    
			<!--[if IE]>
			<link type="text/css" rel="stylesheet" href="{$GLOBALS['rootURL']}css/ie.css" />
			<![endif]-->
			<link media="screen" rel="stylesheet" href="{$GLOBALS['rootURL']}script/colorbox/example1/colorbox.css" />
						
			<script src="{$GLOBALS['rootURL']}script/colorbox/colorbox/jquery.colorbox.js"  type="text/javascript"></script>
			<script src="{$GLOBALS['rootURL']}script/elastic/jquery.elastic.source.js" type="text/javascript" charset="utf-8"></script>
			<script type='text/javascript' src='{$GLOBALS['rootURL']}script/main.js'></script>
Content;
	return $result;
	}
	
	function GetHeader()
	{
		if(isset($_POST['logout']))
		{
			$GLOBALS['user']->logout($_SERVER['HTTP_REFERER']);
		}
		$q = 'Enter Keyword Here';
		if(RequestQueries::GetSearchQuery())
		{
			$q = RequestQueries::GetSearchQuery();
		}
		MasterPage::CreateNavigationLinks();
		$loginLink = '<a href="#Login_SignUp_Box" class = "login" title = "Login Or Sign Up">Sign In Or Sign Up</a>';
		$Forgot_Change_Password_Link = '<a href="#Forgot_Change_Password_Box" class = "forgot_password" title = "Forgot Password">Forgot Password</a>';
		$LoginBox = <<<LoginBox
							<div class='login-panel'>
								<div id="status-message"></div>
								<div class="left-panel">
									<h1>Register</h1>
									<table>
										<tr>
											<td>
												<label>Username</label>
											</td>
											<td>
												<input class="textbox-register" id="R_UN" type="text" />
											</td>
										</tr>
										<tr>
											<td>
												<label>Email</label>
											</td>
											<td>
												<input class="textbox-register" id="R_Email" type="text" />
											</td>
										</tr>
										<tr>
											<td>
												<label>Password</label>
											</td>
											<td>
												<input class="textbox-register" id="R_Password" type="password" />
											</td>
										</tr>
										<tr>
											<td>
												<label>Confirm Password</label>
											</td>
											<td>
												<input class="textbox-register" id="R_ConfirnmPassword" type="password" />
											</td>
										</tr>
										<tr>
											<td>
												&nbsp;
											</td>
											<td>
												<input id="btnRegister" class="button" type="button" value="Register" onclick="register()" />
											</td>
										</tr>
									</table>
								</div>
								<div class="right-panel">
									<h1>
										Sign In</h1>
									<table>
										<tr>
											<td>
												<label>Username</label>
											</td>
											<td>
												&nbsp;
											</td>
											<td>
												<input class="textbox-login" id="L_UN" type="text" />
											</td>
										</tr>
										<tr>
											<td>
												<label>Password</label>
											</td>
											<td>
												&nbsp;
											</td>
											<td>
												<input class="textbox-login" id="L_Password" type="password" />
											</td>
										</tr>
										<tr>
											<td style="padding-top: 5px; padding-bottom: 5px;" colspan="3">
												<input class="textbox" id="L_KeepLogin" type="checkbox" /><label>&nbsp;Keep me logged
													in on this computer</label>
											</td>
										</tr>
										<tr>
											<td>
												<input class="button" id="btnLogin" type="button" value="Login" onclick="login()" />
											</td>
										</tr>
										<tr>
											<td style="padding-top: 5px; padding-bottom: 5px;" colspan="3">
		{$Forgot_Change_Password_Link}
											</td>
										</tr>
									</table>
								</div>
								<div class="cl"></div>
							</div>
LoginBox;
		$Forgot_Change_Password_Box = <<<PasswordBox
							<div class='login-panel'>
								<div id="status-message-password"></div>
								
								<div class="right-panel">
									<h1>
										Forgot Password</h1>
									<table>
										<tr>
											<td>
												<label>Username</label>
											</td>
											<td>
												&nbsp;
											</td>
											<td>
												<input class="textbox-login" id="FP_UN" type="text" />
											</td>
										</tr>
										<tr>
											<td>
												<input class="button" id="btnForgotPassword" type="button" value="Request" onclick="forgotpassword()" />
											</td>
										</tr>
										<tr>
											<td style="padding-top: 5px; padding-bottom: 5px;" colspan="3">
		{$loginLink}
											</td>
										</tr>
									</table>
								</div>
								<div class="cl"></div>
							</div>
PasswordBox;
		$Report_Link_Box = <<<Report_Link_Box
							<div class='login-panel'>														
								<div class="right-panel">
									<h1>Restricted Access ... !!!</h1>
									<div style = "width:100%; text-align:center;">{$loginLink}</div>
								</div>
								<div class="cl"></div>
							</div>
Report_Link_Box;
		if($GLOBALS['user']->is_loaded())
		{            
			$username = MemberDBMethods::GetUserName($GLOBALS['user']->userID);
			$loginLink = '<a href="javascript:document.logoutform.submit();" class = "logout" title = "Loging Out">Log Out</a>|
						  <a href = "' . Settings::GetRootURL() . 'profile/' . $username . '/">My Profile</a>';
			$LoginBox = '<div id="login-panel">
							<div id="status-message">
								<div id = "loading-timer" style = "text-align:center; width:100%;"><img src = "' . Settings::GetRootURL() . 'images/website/loading.gif" height = "25px"/></div>
								<form id = "logoutform" name = "logoutform" method = "post"><input name = "logout" type = "hidden" value = "1"/></form>
							</div>
						 </div>';
			$Forgot_Change_Password_Box = '<div style = "width:300px; height:50px; text-align:center; padding-top:20px;"><span class = "messagefail">Operation Denied ... !!!</span></div>';
			$Report_Link_Box = <<<Report_Link_Box
							<div class='login-panel'>
								<div id="status-message-Report-link"></div>								
								
									<h1>Report Link</h1>
									<div style = "width:100%; text-align:center; padding-top:10px;">
										<input id = "reportStoryID" type = "hidden" value = "0" />
										<textarea type="text" id = "txtReportLink" style = "height:25px; width:580px; height:100px;"></textarea>
										<br/><br/><input type="button" value="Report" onclick="reportlink()" />
									</div>
							</div>
Report_Link_Box;
		}		
		$result = <<<HEADER_TEXT
		<!--header starts here -->
		<div class="header-wrap">
			<div id="header" class="page wrapper">
                                <a href = "{$GLOBALS['rootURL']}"><img alt="" src="{$GLOBALS['rootURL']}images/logo-sopider.jpg" class="logo" /></a>
				<div class="header-contents">
                    <p class="nav">{$loginLink}|<a href="{$GLOBALS['rootURL']}pages/contactus.php">Contact us</a>|<a href="{$GLOBALS['rootURL']}pages/faq.php">FAQ</a></p>
                    <form id = "formSearch" method = "get" action = "{$GLOBALS['rootURL']}pages/search.php">
                       <p><input type="text" class="sprites search-field" name = "q" value="{$q}" onblur ="WaterMark(this, event, 'Enter Keyword Here')" onfocus ="WaterMark(this, event, 'Enter Keyword Here')" /><input type="submit" value="" class="sprites btn-search" /></p>
                    </form>
                    <div style='display:none'>
						<div id='Login_SignUp_Box'>
		{$LoginBox}
						</div>
						<div id='Forgot_Change_Password_Box'>
		{$Forgot_Change_Password_Box}
						</div>
						<div id='Report_Link_Box'>
		{$Report_Link_Box}
						</div>
					</div>					
				</div>
			</div>								    
		</div>
		<!--header ends -->				
HEADER_TEXT;
		
		return $result;
		
	}
		
	function GetFooter()
	{				
		$result = <<<FOOTER_HTML
		<!--footer area starts here -->
		<div class="footer-wrap">
			<div id="footer" class="page">
				<div class="copyrights">
					<p>Copyrights&#169; 2010 Sopider. All rights reserved.</p>
					<p>
						<a href="{$GLOBALS['rootURL']}pages/tos.php">Terms of Use</a> | 
						<a href="{$GLOBALS['rootURL']}pages/privacypolicy.php">Privacy Policy</a> | 
						<a href="{$GLOBALS['rootURL']}pages/disclaimer.php">Disclaimer</a></p>
                                                <p>Design Credits: <a href="http://www.graphicrangers.com/">Graphic Rangers</a></p>
				</div>
				<div class="footer-lists">
					<ul>
						<li><a href="{$GLOBALS['rootURL']}">HOME</a></li>						
						<li><a href="{$GLOBALS['rootURL']}/pages/search.php?q=">SEARCH SOPIDER</a></li>						
						<li><a href="http://feeds.feedburner.com/sopider">RSS FEEDS</a></li>						
					</ul>
				</div>
				<div class="footer-lists">
					<ul>
						<li><a href="{$GLOBALS['rootURL']}pages/faq.php">FREQUENT ASKED QUESTIONS</a></li>
						<li><a href="{$GLOBALS['rootURL']}pages/contactus.php">CONTACT US</a></li>
						<li><a href="{$GLOBALS['rootURL']}pages/contactus.php">REPORT A WEBSITE BUG</a></li>
                        <li><a href="{$GLOBALS['rootURL']}pages/contactus.php">ADVERTISE</a></li>
					</ul>
				</div>
				<div class="footer-lists">
					 <ul>
                        <li><a href="{$GLOBALS['rootURL']}">POPULAR</a></li>
                        <li><a href="{$GLOBALS['rootURL']}perspective/">PERSPECTIVE</a></li>                        
                    </ul>
				</div>
				<div class="cl"></div>
			</div>
		</div>
                <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-18001885-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
		<!--footer ends-->
FOOTER_HTML;
		return $result;
	}
	
	function CreateNavigationLinks()
	{		
		
		/*$connection = Settings::ConnectDB(); 		
		if($connection)
		{
			$db_selected = mysql_select_db($GLOBALS['databaseName'], $connection) or die(mysql_error());
			if($db_selected)
			{*/				
				$GLOBALS['LiteralCategoryLinks'] = MasterPage::GetSingleCategoryText(true);
			/*}
			mysql_close($connection);
		}*/	
	}
	
	function GetSingleCategoryText($IsAllAllowed)
	{
		$result = "";	
		if($IsAllAllowed)
		{
			$result = sprintf("<li><a href='%1\$s'>All</a></li>", $GLOBALS['rootURL']);
		}
		
		$QueryResult =  mysql_query("SELECT * FROM tbl_category ORDER BY CategoryName")or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		while($row != false)
		{
			$result .= sprintf("<li><a href='%1\$s'>%2\$s</a></li>", $GLOBALS['rootURL']. $row["CategoryURL"] . "/", ucfirst($row["CategoryName"]));
			$row = mysql_fetch_array($QueryResult);					
		}
		return $result;	
	}
}
?>