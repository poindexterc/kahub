<?php
//require_once "HelpingMethods.php" ;
require_once 'ApplicationSettings.php' ;
require_once 'MemberDBMethods.php';
class HelpingDBMethods
{	
	function SaveURL($url, $title)
	{
		$Query = "INSERT INTO tblurls (URLTitle, URL) VALUES  ('" . $title . "', '" . $url . "')";
		$QueryResult =  mysql_query($Query)or die(mysql_error());
	}
	
	function GetAllComments($url)
	{		
		$result = "";
		$storyID = HelpingDBMethods::GetStoryID($url);
		$Query = "SELECT DISTINCT Comment_Associated_Text FROM tbl_comments WHERE (StoryID = $storyID)";
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		while( $row != false)
		{
			$result .= $row['Comment_Associated_Text'];
			$row = mysql_fetch_array($QueryResult);
			if($row != false)
			{
				$result .= ',';
			}
		}
		
		return $result;
	}
	
	function GetStoryID($url)
	{
		$result = 0;
		$Query = "SELECT StoryID FROM tbl_story WHERE (Story_URL  = '$url')";	
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		$row = mysql_fetch_array($QueryResult);
		if($row!=false)
		{
			$result = $row['StoryID'];
		}
		return $result;		
	}
	
	function GetImageData($ImageID)
	{
		$result = 'images/author-1.jpg';
		if($ImageID > 0)
		{
			$Query = "SELECT ImageSrc FROM tbl_images WHERE (ImageID  = $ImageID)";	
			$QueryResult =  mysql_query($Query)or die(mysql_error());
			$row = mysql_fetch_array($QueryResult);
			if($row!=false)
			{
				$result = $row['ImageSrc'];
			}
		}
		return $result;
	}
	
	function PostComments($StoryID, $text_selected, $Comments, $MemberID, $ReplyTo)
	{
		$DateTime = gmdate("Y-m-d H-i-s");//date('Y-m-d H-i-s')
		$Query = "INSERT INTO tbl_comments (StoryID, Comment_Associated_Text, Comment_Text,  MemberID, Reply_To) 
				VALUES (" . $StoryID . ", '" . $text_selected . "', '" . $Comments . "', " . $MemberID . ", " . $ReplyTo . ")";
		$QueryResult =  mysql_query($Query)or die(mysql_error());
		return mysql_insert_id();
	}
}

?>